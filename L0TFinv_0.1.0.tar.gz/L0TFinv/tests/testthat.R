library(testthat)
library(L0TFinv)

test_check("L0TFinv")
